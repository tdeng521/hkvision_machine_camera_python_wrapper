import os
import ctypes
import numpy as np 
import cv2 as cv

class Camera:
    def __init__(self,dllpath):
        #self.camera_lib = np.ctypeslib.load_library(dllpath,'.')
        self.camera_lib = ctypes.cdll.LoadLibrary(dllpath)

    def initCamera(self):
        ret = self.camera_lib.initCamera()
        return ret

    def captureImageToFile(self,imagePath):
        ret = self.camera_lib.captureImageToFile(imagePath)
        return ret
    
    def captureImage(self,image,width,height,channels):
        print("capture image")
        self.camera_lib.captureImage.argtypes = [ctypes.c_char_p, ctypes.c_int,ctypes.c_int,ctypes.c_int]
        self.camera_lib.captureImage.restype = ctypes.c_int
        ret = self.camera_lib.captureImage(ctypes.c_char_p(image.ctypes.data) ,width,height,channels)
        
        return ret;


    def closeCamera(self):
        ret = self.camera_lib.closeCamera()
        return ret


if __name__ == "__main__":
    #1.创建camera实例
    cam = Camera("ImageCapture.dll")
	#2.初始化camera
	ret = cam.initCamera()
	if ret != 1:
		print("xx:failed to init camera")
		return
	#3.申请图像空间
    img=np.zeros((512,512,3), np.uint8)
	#4.采集图像
    ret = cam.captureImage(img,512,512,3)
	if ret != 1:
		print("xx:failed to capture image")
		return 
    print(img.shape)
	#
    cv.imshow("new image", img)
    cv.waitKey(0)
    # cam = Camera("ImageCapture.dll")
    # ret = cam.initCamera()
    # if ret != 1:
    #     print("fail to init camera!")

    # ret = cam.captureImageToFile("pytest.jpg")
    # if ret != 1:
    #     print("fait to capture image")
    
    # cam.closeCamera()

    
